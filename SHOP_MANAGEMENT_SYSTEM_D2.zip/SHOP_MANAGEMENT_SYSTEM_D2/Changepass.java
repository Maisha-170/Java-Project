import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;




public class Changepass extends JFrame implements ActionListener
{
	private JLabel oldPassLabel, newPassLabel;
	private JPasswordField oldPassTF, newPassTF;
	private JButton confirmBtn, backBtn, logoutBtn;
    private JPanel panel;
	private Font f1;
	String userId;
	private String status;
	private int access=0;
	
	public Changepass(String userId)
	{
		super("Customer Change Password Window");
		this.setSize(850,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.userId = userId;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		f1 = new Font("Arial", Font.ITALIC + Font.BOLD,20);
		
		oldPassLabel = new JLabel("Old Password :");
		oldPassLabel.setBounds(70, 50, 200, 30);
		oldPassLabel.setFont(f1);
		panel.add(oldPassLabel);
		
		newPassLabel = new JLabel("New Password :");
		newPassLabel.setBounds(70, 130, 200, 30);
		newPassLabel.setFont(f1);
		panel.add(newPassLabel);
		
	     
		oldPassTF = new JPasswordField();
		oldPassTF.setBounds(290, 50, 130, 30);
		panel.add(oldPassTF);
		
		
		newPassTF = new JPasswordField();
		newPassTF.setBounds(290, 130, 130, 30);
		panel.add(newPassTF);
		
		confirmBtn = new JButton("Confirm");
		confirmBtn.setBounds(200, 350, 130, 40);
		confirmBtn.addActionListener(this);
		panel.add(confirmBtn);
		
		
		backBtn = new JButton("Back");
		backBtn.setBounds(459,350, 130, 40);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(600, 50, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
		
		
		this.add(panel);
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			Employee e = new Employee(userId);
			e.setVisible(true);
			this.setVisible(false);
		}
		
		if(text.equals(logoutBtn.getText()))
		{
			SignUp su = new SignUp();
			su.setVisible(true);
			this.setVisible(false);
		}
		
		if(text.equals(confirmBtn.getText()))
		{
			confirmFromDB();
			if(access==1){
				updateInDB();
				
				access = 0;
			}
			else if(access==0){
				JOptionPane.showMessageDialog(this," Oops!!!there have a problem");
			}
		}
	
	}
	
	public void confirmFromDB()
	
	{

		 String query = "SELECT password,`status`  FROM login where `userId`='"+userId+"';";
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        
		 
		
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			while(rs.next()){
				String password = rs.getString("password");
				status = rs.getString("status");
				if(password.equals(oldPassTF.getText()))
				{
					access = 1;
					System.out.println("pass: "+password);
				}
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
			
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();
                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
		
		
	}
	
	public void updateInDB()
	{
        Connection con=null;//for connection
        Statement st = null;//for query execution
        
		String newPass = newPassTF.getText();
		 boolean flag=true;
		
		if(newPass.length()==0)
		{
		JOptionPane.showMessageDialog(null,"Please provide new password ");
          flag=false;
		  	
		}
		
		
		 if(flag){
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			String query = "UPDATE login SET password="+newPassTF.getText()+" where `userId`='"+userId+"';";
			st.executeUpdate(query);
			System.out.println(query);
			st.close();
			con.close();
			
			JOptionPane.showMessageDialog(this,"success!!!");
			
			
			Customer c = new Customer(userId);
			c.setVisible(true);
			this.setVisible(false);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
			}
		 }
	}
	
	
	
}
	

	
