import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.*;


public class PurchasesInformation extends JFrame implements ActionListener

{
	private JLabel welcomeLabel;
    private JTable myTable;
	private JScrollPane tableScrollPane;
    private JButton  backBtn, logoutBtn;
	
	private JPanel panel;
	String userId;
	
	
	
	public PurchasesInformation(String userId)
	{
		super("View Product");
		this.userId = userId;
		
		this.setSize(850, 550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		welcomeLabel = new JLabel("Welcome, "+userId);
		welcomeLabel.setBounds(0, 0, 100, 30);
		panel.add(welcomeLabel);
		
	
		 myTable = new JTable();
		
		
		
		String []columnNames = { "PurchaseID","ProductID",  "quantity","amount"};
		
		 DefaultTableModel model = new DefaultTableModel();
         model.setColumnIdentifiers(columnNames);
		
		
		 String query = "select * from purchaseInfo where userID ='"+this.userId+"'";
		 
		Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
		
			while(rs.next())
			{
               String col1 = rs.getString("purchaseID");
               String col2 = rs.getString("productID");
               String col3 = rs.getString("quantity");  
               String col4 = rs.getString("amount");  
			   model.addRow(new Object[]{col1, col2, col3,col4});
		
			}
			
			myTable.setModel(model);
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex)
			{
				
				System.out.println("Exception : " +ex.getMessage());
			}
        }
			
		
	   tableScrollPane = new JScrollPane(myTable);
		tableScrollPane.setBounds(100,100,500,100);
		panel.add(tableScrollPane);
	
	
	    
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(700, 20, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
		
		
		
		backBtn = new JButton("Back");
		backBtn.setBounds(350, 400, 120, 30);
		backBtn.addActionListener(this);
		panel.add(backBtn);
	
	
	
	
	
	this.add(panel);
	}
	
	
	
	public void actionPerformed(ActionEvent ae){
		
		
		
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			Customer ch = new Customer(userId);
			ch.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
}