import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;



public class CustomerInformation extends JFrame implements ActionListener
{
	
	JLabel welcomeLabel;
	private JLabel userLabel1,userLabel2, addressLabel, phonenoLabel;
	private JTextField userTF,  addressTF, phonenoTF1,phonenoTF2;
	private JButton autoPassBtn, backBtn, logoutBtn ,updateBtn, delBtn;
	private JPanel panel;
    String userId;
	public CustomerInformation(String userId)
	{
		super("Customer Information");
		this.userId = userId;
		
		this.setSize(850, 550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		welcomeLabel = new JLabel("Welcome, "+userId);
		welcomeLabel.setBounds(350, 50, 100, 30);
		panel.add(welcomeLabel);
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(600, 50, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
		
		userLabel1 = new JLabel("User Name: ");
		userLabel1.setBounds(150, 90, 120, 30);
		panel.add(userLabel1);
		
		addressLabel = new JLabel("address : ");
		addressLabel.setBounds(150, 130, 120, 30);
		panel.add(addressLabel);
		
		userTF = new JTextField();
		userTF.setBounds(260, 90, 150, 30);
		panel.add(userTF);

		
		addressTF = new JTextField();
		addressTF.setBounds(260, 130, 150, 30);
		panel.add(addressTF);
		
		phonenoLabel = new JLabel("Phone No. : ");
		phonenoLabel.setBounds(150, 170, 120, 30);
		panel.add(phonenoLabel);
		
		phonenoTF1 = new JTextField("+880");
		phonenoTF1.setBounds(260, 170, 35, 30);
		phonenoTF1.setEnabled(false);
		phonenoTF1.setForeground(Color.BLACK);
		panel.add(phonenoTF1);
		
		phonenoTF2 = new JTextField();
		phonenoTF2.setBounds(295, 170, 115, 30);
		panel.add(phonenoTF2);
		
		
		
		updateBtn = new JButton("Update");
		updateBtn.setBounds(200, 400, 120, 30);
		updateBtn.addActionListener(this);
		panel.add(updateBtn);
		
		delBtn = new JButton("Delete");
		delBtn.setBounds(330, 400, 120, 30);
		delBtn.addActionListener(this);
		panel.add(delBtn);
		
		
		backBtn = new JButton("Back");
		backBtn.setBounds(460, 400, 100, 30);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		loadFromDB();
		this.add(panel);
	}
	
	
	public void loadFromDB()
	{
		String query = "SELECT * from customer where userID ='"+this.userId+"'";
		
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
			String cName = null;
			String phnNo = null;
			String address = null;
					
			while(rs.next())
			{
                cName = rs.getString("customerName");
				phnNo = rs.getString("phoneNumber");
				address = rs.getString("address");
				
				flag=true;
				
				userTF.setText(cName);
				phonenoTF1.setText("+880");
				phonenoTF2.setText(phnNo.substring(4,14));
				addressTF.setText(address);
			
				
				
			}
			if(!flag)
			{
				userTF.setText("");
				phonenoTF1.setText("");
				phonenoTF2.setText("");
				addressTF.setText("");
	
				JOptionPane.showMessageDialog(this,"Invalid ID"); 
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex)
			{
				
				System.out.println("Exception : " +ex.getMessage());
			}
        }
		
		
		
	}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			Customer ch = new Customer(userId);
			ch.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
	
		else if(text.equals(updateBtn.getText()))
		{
			updateInDB();
		}
		else if(text.equals(delBtn.getText()))
		{
			deleteFromDB();
		}
	
		
		else{}
	}
	
	
	
	public void updateInDB()
	{
		boolean flag=true;
		
		String newId = userTF.getText();
		
		String address = addressTF.getText();
		
		
		String phnNo = "";
		try
		{
			phnNo = phonenoTF1.getText()+Integer.parseInt(phonenoTF2.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "Phone number  is Integer!!!");
			flag=false;
			
		}
		

		
		String query = "UPDATE customer SET Name='"+newId+"', phoneNumber = '"+phnNo+"', address = '"+address+"' WHERE userID='"+this.userId+"'";	
        Connection con=null;//for connection
        Statement st = null;//for query execution
		System.out.println(query);
         if(flag){
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(query);
			st.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
			
			Customer ch = new Customer(userId);
			ch.setVisible(true);
			this.setVisible(false);
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			JOptionPane.showMessageDialog(this, "Oops !!!");
		}
		 }
	}
	
	public void deleteFromDB()
	{

		String query1 = "DELETE from customer WHERE userID='"+this.userId+"';";
		String query2 = "DELETE from login WHERE userID='"+this.userId+"';";
		System.out.println(query1);
		System.out.println(query2);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.execute(query2);
			stm.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
			
			
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
			

		}
        catch(Exception ex)
		{
			JOptionPane.showMessageDialog(this, "Oops !!!");
        }
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
}