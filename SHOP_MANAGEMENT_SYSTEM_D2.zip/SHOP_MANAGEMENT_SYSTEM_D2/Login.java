import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

public class Login extends JFrame implements MouseListener, ActionListener
{
	JLabel title, userLabel, passLabel,imgLabel;
	JTextField userTF;
	JPasswordField passPF;
	JButton loginBtn, exitBtn, SignUpBtn,showpasswordBtn;
	private ImageIcon pic;
	JPanel panel;
	
	public Login()
	{
		super("Login Window");
		
		this.setSize(800, 450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		title = new JLabel("Shop Management System");
		title.setBounds(300, 50, 350, 30);
		panel.add(title);
		
		userLabel = new JLabel("User ID : ");
		userLabel.setBounds(300, 100, 60, 30);
		panel.add(userLabel);
		
		userTF = new JTextField();
		userTF.setBounds(370, 100, 100, 30);
		panel.add(userTF);
		
		passLabel = new JLabel("Password : ");
		passLabel.setBounds(300, 150, 70, 30);
		panel.add(passLabel);
		
		passPF = new JPasswordField();
		passPF.setBounds(370, 150, 100, 30);
		passPF.setEchoChar('#');
		panel.add(passPF);
		
		loginBtn = new JButton("Login");
		loginBtn.setBounds(300, 200, 80, 30);
		loginBtn.addActionListener(this);
		panel.add(loginBtn);
		
		showpasswordBtn = new JButton("Show Password");
		showpasswordBtn.setBounds(495, 150, 130, 30);
		showpasswordBtn.addMouseListener(this);
		panel.add(showpasswordBtn);
		
		
		
		exitBtn = new JButton("Exit");
		exitBtn.setBounds(405, 200, 80, 30);
		exitBtn.addActionListener(this);
		panel.add(exitBtn);
		
		SignUpBtn = new JButton("SignUP");
		SignUpBtn.setBounds(340, 260, 80, 30);
		SignUpBtn.addActionListener(this);
		panel.add(SignUpBtn);
		
		pic = new ImageIcon("pi.jpg");
		imgLabel = new JLabel(pic);
		imgLabel.setBounds(270, 50, 350, 30);
		panel.add(imgLabel);
		
		
		this.add(panel);
	}	
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	public void mouseClicked(MouseEvent me){}
	public void mouseReleased(MouseEvent me)
	{
		if(me.getSource().equals(showpasswordBtn))
		{
			passPF.setEchoChar('#');
		}
	}
	public void mousePressed(MouseEvent me)
	{
		if(me.getSource().equals(showpasswordBtn))
		{
			passPF.setEchoChar((char)0);
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		if(text.equals(loginBtn.getText()))
		{
			checkLogin();
		}
		else if(text.equals(SignUpBtn.getText()))
		{
			SignUp su = new SignUp();
			su.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(exitBtn.getText()))
		{
			System.exit(0);
		}
		else{}
	}
	
	public void checkLogin()
	{
		String query = "SELECT `userId`, `password`, `status` FROM `login`;";     
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;			
			while(rs.next())
			{
                String userId = rs.getString("userId");
                String password = rs.getString("password");
				int status = rs.getInt("status");
				
				if(userId.equals(userTF.getText()) && password.equals(passPF.getText()))
				{
					flag=true;
					if(status==0)
					{
						Employee eh = new Employee(userId);
						eh.setVisible(true);
						this.setVisible(false);
					}
					else if(status==1)
					{
						Customer ch = new Customer(userId);
						ch.setVisible(true);
						this.setVisible(false);
					}
					else{}
				}
			}
			if(!flag)
			{
				JOptionPane.showMessageDialog(this,"Invalid ID or Password"); 
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
	}
}